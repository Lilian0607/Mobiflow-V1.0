
package com.venun.engine

import android.content.Context
import android.util.Log
import android.view.View
import android.webkit.ConsoleMessage
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient

class WebEngine(private val context: Context) {

    fun create(): WebView {

        val webView = WebView(context)

        // 1. Configuration générale
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true

            allowFileAccess = true
            allowContentAccess = false

            // Autoriser les ressources locales de l'application
            allowFileAccessFromFileURLs = true
            allowUniversalAccessFromFileURLs = false

            mixedContentMode =
                WebSettings.MIXED_CONTENT_NEVER_ALLOW

            javaScriptCanOpenWindowsAutomatically = false
        }

        // 2. Gestion des interactions
        webView.isClickable = true
        webView.isFocusable = true
        webView.isFocusableInTouchMode = true

        webView.overScrollMode = View.OVER_SCROLL_NEVER

        // 3. Gestion du chargement des pages
        webView.webViewClient = object : WebViewClient() {

            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean {
                return false
            }

            override fun onPageFinished(
                view: WebView,
                url: String
            ) {
                super.onPageFinished(view, url)

                Log.d("VENUN_ENGINE", "Page chargée : $url")
            }

            override fun onReceivedError(
                view: WebView,
                request: WebResourceRequest,
                error: WebResourceError
            ) {
                super.onReceivedError(view, request, error)

                Log.e(
                    "VENUN_ENGINE",
                    "Erreur WebView : ${error.description}"
                )
            }
        }

        // 4. Diagnostic JavaScript
        webView.webChromeClient = object : WebChromeClient() {

            override fun onConsoleMessage(
                consoleMessage: ConsoleMessage
            ): Boolean {

                Log.e(
                    "VENUN_JS",
                    "${consoleMessage.message()} | " +
                    "Ligne : ${consoleMessage.lineNumber()} | " +
                    "Fichier : ${consoleMessage.sourceId()}"
                )

                return true
            }
        }

        // 5. Chargement de l'application
        webView.loadUrl(
            "file:///android_asset/apps/venun/index.html"
        )

        return webView
    }
}
