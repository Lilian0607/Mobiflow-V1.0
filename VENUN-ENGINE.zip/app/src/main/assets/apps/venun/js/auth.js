
// ==========================================
// MOBIFLOW — AUTHENTIFICATION SUPABASE
// ACCUEIL + INSCRIPTION + CONNEXION
// ==========================================

const mobiflowClient = window.supabase.createClient(
  SUPABASE_URL,
  SUPABASE_PUBLISHABLE_KEY
);

// ÉLÉMENTS DE L'INTERFACE
const welcomeSection = document.getElementById("welcomeSection");
const loginSection = document.getElementById("loginSection");
const registerSection = document.getElementById("registerSection");

const loginForm = document.getElementById("loginForm");
const registerForm = document.getElementById("registerForm");

const loginMessage = document.getElementById("loginMessage");
const registerMessage = document.getElementById("registerMessage");

const loginButton = document.getElementById("loginButton");
const registerButton = document.getElementById("registerButton");

// ==========================================
// AFFICHER UN MESSAGE
// ==========================================

function showMessage(element, message, type = "") {
  element.textContent = message;
  element.className = "message" + (type ? " " + type : "");
}

// ==========================================
// NAVIGATION ENTRE LES 3 ÉCRANS
// ==========================================

function showScreen(screen) {
  [welcomeSection, loginSection, registerSection].forEach(section => {
    section.classList.add("hidden");
  });

  screen.classList.remove("hidden");

  window.scrollTo({
    top: 0,
    behavior: "smooth"
  });

  showMessage(loginMessage, "");
  showMessage(registerMessage, "");
}

// Accueil vers inscription
document.getElementById("startButton").addEventListener("click", () => {
  showScreen(registerSection);
});

// Accueil vers connexion
document.getElementById("welcomeLogin").addEventListener("click", () => {
  showScreen(loginSection);
});

// Inscription vers connexion
document.getElementById("showLogin").addEventListener("click", () => {
  showScreen(loginSection);
});

// Connexion vers inscription
document.getElementById("showRegister").addEventListener("click", () => {
  showScreen(registerSection);
});

// Retour vers accueil
document.getElementById("registerBack").addEventListener("click", () => {
  showScreen(welcomeSection);
});

document.getElementById("loginBack").addEventListener("click", () => {
  showScreen(welcomeSection);
});

// ==========================================
// AFFICHER / MASQUER LES MOTS DE PASSE
// ==========================================

document.querySelectorAll("[data-toggle]").forEach(button => {

  button.addEventListener("click", () => {

    const input = document.getElementById(button.dataset.toggle);

    const isPassword = input.type === "password";

    input.type = isPassword ? "text" : "password";

    button.setAttribute(
      "aria-label",
      isPassword ? "Masquer le mot de passe" : "Afficher le mot de passe"
    );

    button.textContent = isPassword ? "◎" : "◉";

  });

});

// ==========================================
// SE SOUVENIR DE MOI
// ==========================================

const savedEmail = localStorage.getItem("mobiflow_saved_email");

if (savedEmail) {
  document.getElementById("loginEmail").value = savedEmail;
  document.getElementById("rememberMe").checked = true;
}

// ==========================================
// INSCRIPTION
// ==========================================

registerForm.addEventListener("submit", async (event) => {

  event.preventDefault();

  const lastName = document.getElementById("lastName").value.trim();

  const firstName = document.getElementById("firstName").value.trim();

  const phone = document.getElementById("phone").value.trim();

  const email = document.getElementById("registerEmail")
    .value.trim()
    .toLowerCase();

  const password = document.getElementById("registerPassword").value;

  const confirmPassword = document.getElementById("confirmPassword").value;

  const acceptedTerms = document.getElementById("acceptTerms").checked;

  showMessage(registerMessage, "");

  // Vérification des champs
  if (!lastName || !firstName || !phone || !email || !password || !confirmPassword) {

    showMessage(
      registerMessage,
      "Remplis tous les champs obligatoires.",
      "error"
    );

    return;
  }

  // Vérification des conditions
  if (!acceptedTerms) {

    showMessage(
      registerMessage,
      "Tu dois accepter les conditions d'utilisation.",
      "error"
    );

    return;
  }

  // Vérification du mot de passe
  if (password.length < 8) {

    showMessage(
      registerMessage,
      "Le mot de passe doit contenir au moins 8 caractères.",
      "error"
    );

    return;
  }

  // Confirmation du mot de passe
  if (password !== confirmPassword) {

    showMessage(
      registerMessage,
      "Les deux mots de passe ne correspondent pas.",
      "error"
    );

    return;
  }

  registerButton.disabled = true;
  registerButton.innerHTML = "Création du compte...";

  try {

    const { data, error } = await mobiflowClient.auth.signUp({

      email: email,

      password: password,

      options: {

        data: {
          first_name: firstName,
          last_name: lastName,
          phone: phone
        }

      }

    });

    if (error) {
      throw error;
    }

    // Si Supabase ouvre directement une session
    if (data.session) {

      showMessage(
        registerMessage,
        "Compte créé ! Ouverture de Mobiflow...",
        "success"
      );

      window.location.replace("index.html");

      return;
    }

    // Si une confirmation par email est nécessaire
    showScreen(loginSection);

    document.getElementById("loginEmail").value = email;

    showMessage(
      loginMessage,
      "Inscription enregistrée ! Consulte ton email pour confirmer ton compte.",
      "success"
    );

  } catch (error) {

    console.error("Erreur d'inscription :", error);

    showMessage(
      registerMessage,
      "Inscription impossible : " + error.message,
      "error"
    );

  } finally {

    registerButton.disabled = false;

    registerButton.innerHTML =
      'S’inscrire <span class="btn-arrow">→</span>';

  }

});

// ==========================================
// CONNEXION
// ==========================================

loginForm.addEventListener("submit", async (event) => {

  event.preventDefault();

  const email = document.getElementById("loginEmail")
    .value.trim()
    .toLowerCase();

  const password = document.getElementById("loginPassword").value;

  const remember = document.getElementById("rememberMe").checked;

  showMessage(loginMessage, "");

  loginButton.disabled = true;
  loginButton.innerHTML = "Connexion...";

  try {

    const { data, error } = await mobiflowClient.auth.signInWithPassword({

      email: email,

      password: password

    });

    if (error) {
      throw error;
    }

    if (!data.session) {

      throw new Error(
        "Aucune session ouverte. Réessaie de te connecter."
      );

    }

    // Mémoriser uniquement l'adresse email
    if (remember) {

      localStorage.setItem("mobiflow_saved_email", email);

    } else {

      localStorage.removeItem("mobiflow_saved_email");

    }

    showMessage(
      loginMessage,
      "Connexion réussie !",
      "success"
    );

    window.location.replace("index.html");

  } catch (error) {

    console.error("Erreur de connexion :", error);

    showMessage(
      loginMessage,
      "Connexion impossible : " + error.message,
      "error"
    );

  } finally {

    loginButton.disabled = false;

    loginButton.innerHTML =
      'Se connecter <span class="btn-arrow">→</span>';

  }

});

// ==========================================
// MOT DE PASSE OUBLIÉ
// ==========================================

document.getElementById("forgotPassword").addEventListener("click", async () => {

  const email = document.getElementById("loginEmail")
    .value.trim()
    .toLowerCase();

  if (!email) {

    showMessage(
      loginMessage,
      "Saisis ton adresse email avant de continuer.",
      "error"
    );

    document.getElementById("loginEmail").focus();

    return;
  }

  showMessage(
    loginMessage,
    "Envoi du lien de réinitialisation..."
  );

  try {

    const { error } = await mobiflowClient.auth.resetPasswordForEmail(
      email,
      {
        redirectTo: window.location.origin + "/reset-password.html"
      }
    );

    if (error) {
      throw error;
    }

    showMessage(
      loginMessage,
      "Si cette adresse correspond à un compte, un lien de réinitialisation sera envoyé.",
      "success"
    );

  } catch (error) {

    console.error("Erreur de réinitialisation :", error);

    showMessage(
      loginMessage,
      "Envoi impossible : " + error.message,
      "error"
    );

  }

});

// ==========================================
// VÉRIFIER SI UNE SESSION EXISTE DÉJÀ
// ==========================================

async function checkExistingSession() {

  try {

    const { data, error } = await mobiflowClient.auth.getSession();

    if (error) {
      throw error;
    }

    if (data.session) {

      window.location.replace("index.html");

    }

  } catch (error) {

    console.error(
      "Vérification de session impossible :",
      error
    );

  }

}

checkExistingSession();
