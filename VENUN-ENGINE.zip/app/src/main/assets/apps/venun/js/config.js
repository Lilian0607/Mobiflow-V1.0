// ========================================
// MOBIFLOW — CONFIGURATION SUPABASE
// ========================================
const SUPABASE_URL = "https://ubmopfjitieiustmfqbu.supabase.co";
const SUPABASE_PUBLISHABLE_KEY =
  "sb_publishable_15ImFzn375QagoxmTAjeLA_L10t0LNn";
// Le client Supabase sera initialisé dans les pages
// après le chargement de la bibliothèque Supabase.