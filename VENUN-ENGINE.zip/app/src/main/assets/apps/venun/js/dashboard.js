
// ==========================================
// MOBIFLOW V2 — TABLEAU DE BORD
// Opérateurs + Historique + Supabase
// ==========================================

const db = window.supabase.createClient(
  SUPABASE_URL,
  SUPABASE_PUBLISHABLE_KEY
);

let currentUser = null;
let currentProfile = null;
let selectedDate = new Date();
let selectedTransactionType = null;

const $ = (id) => document.getElementById(id);

// ==========================================
// OPÉRATEURS
// ==========================================

const OPERATORS = {
  moov: {
    name: "Moov Money",
    logo: "assets/operators/moov.png"
  },
  orange: {
    name: "Orange Money",
    logo: "assets/operators/orange.png"
  },
  wave: {
    name: "Wave",
    logo: "assets/operators/wave.png"
  },
  mtn: {
    name: "MTN Money",
    logo: "assets/operators/mtn.png"
  }
};

function getOperator(operatorCode) {
  return OPERATORS[operatorCode] || {
    name: operatorCode || "Opérateur inconnu",
    logo: ""
  };
}

// ==========================================
// OUTILS
// ==========================================

function on(id, event, callback) {
  const element = $(id);
  if (element) element.addEventListener(event, callback);
}

function setText(id, value) {
  const element = $(id);
  if (element) element.textContent = value;
}

function formatDate(date) {
  return date.toLocaleDateString("fr-FR", {
    weekday: "short",
    day: "numeric",
    month: "long",
    year: "numeric"
  });
}

function dateKey(date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function formatMoney(value) {
  return Number(value || 0).toLocaleString("fr-FR", {
    maximumFractionDigits: 2
  });
}

function showMessage(elementId, message, type = "") {
  const element = $(elementId);
  if (!element) return;

  element.textContent = message;
  element.className = "message";

  if (type) element.classList.add(type);
}

function showTransactionMessage(message, type = "") {
  const element = $("transactionMessage");
  if (!element) return;

  element.textContent = message;
  element.className = "message modal-message";

  if (type) element.classList.add(type);
}

// ==========================================
// NAVIGATION
// ==========================================

function showPage(pageId) {
  document.querySelectorAll(".app-page").forEach((page) => {
    page.classList.add("hidden");
  });

  const selectedPage = $(pageId);
  if (selectedPage) selectedPage.classList.remove("hidden");

  document.querySelectorAll(".nav-item").forEach((button) => {
    button.classList.toggle(
      "active",
      button.dataset.page === pageId
    );
  });

  window.scrollTo({ top: 0, behavior: "smooth" });
}

document.querySelectorAll(".nav-item").forEach((button) => {
  button.addEventListener("click", () => {
    showPage(button.dataset.page);
  });
});

on("openHistoryButton", "click", () => {
  showPage("historyPage");
});

// ==========================================
// CHARGER LE PROFIL
// ==========================================

async function loadProfile() {
  const { data, error } = await db
    .from("profiles")
    .select(
      "user_code, first_name, last_name, phone, ticket_balance"
    )
    .eq("id", currentUser.id)
    .single();

  if (error) {
    console.error("Erreur profil :", error);
    throw new Error(
      "Impossible de charger ton profil. Vérifie les règles RLS."
    );
  }

  currentProfile = data;

  const firstName = data.first_name || "Agent";
  const lastName = data.last_name || "";

  setText("agentName", `${firstName} 👋`);
  setText("userId", data.user_code || "Non disponible");
  setText("ticketBalance", formatMoney(data.ticket_balance));

  setText("profileName", `${firstName} ${lastName}`.trim());
  setText("profileAvatar", firstName.charAt(0).toUpperCase());
  setText("profileUserId", data.user_code || "Non disponible");

  setText(
    "profileTicketBalance",
    formatMoney(data.ticket_balance)
  );

  if ($("profileFirstName")) {
    $("profileFirstName").value = data.first_name || "";
  }

  if ($("profileLastName")) {
    $("profileLastName").value = lastName;
  }

  if ($("profilePhone")) {
    $("profilePhone").value = data.phone || "";
  }

  return data;
}

// ==========================================
// AFFICHER UNE TRANSACTION
// ==========================================

function createTransactionElement(transaction) {
  const item = document.createElement("div");

  const isDeposit =
    transaction.transaction_type === "deposit";

  item.className = isDeposit
    ? "transaction-item deposit-card"
    : "transaction-item withdraw-card";

  // Ligne supérieure : type + montant
  const top = document.createElement("div");
  top.className = "transaction-top";

  const type = document.createElement("span");
  type.className = "transaction-type";
  type.textContent = isDeposit ? "↓ Dépôt" : "↑ Retrait";

  const amount = document.createElement("span");
  amount.className = "transaction-amount";
  amount.textContent =
    `${formatMoney(transaction.amount)} FCFA`;

  top.append(type, amount);

  // Heure et numéro du client
  const time = new Date(transaction.created_at)
    .toLocaleTimeString("fr-FR", {
      hour: "2-digit",
      minute: "2-digit"
    });

  const details = document.createElement("div");
  details.className = "transaction-details";
  details.textContent =
    `${time} · Client : ${transaction.client_phone || "Non renseigné"}`;

  // Référence
  const reference = document.createElement("div");
  reference.className = "transaction-details";
  reference.textContent =
    `Référence : ${transaction.reference || "Non renseignée"}`;

  // Commission
  const commission = document.createElement("div");
  commission.className =
    "transaction-details transaction-commission";

  commission.textContent =
    `Commission : ${formatMoney(transaction.commission)} FCFA`;

  // Opérateur et logo
  const operator = getOperator(transaction.operator);

  const operatorContainer = document.createElement("div");
  operatorContainer.className = "transaction-operator";

  if (operator.logo) {
    const logo = document.createElement("img");
    logo.className = "operator-logo";
    logo.src = operator.logo;
    logo.alt = operator.name;

    const operatorName = document.createElement("span");
    operatorName.className = "operator-name";
    operatorName.textContent = operator.name;

    logo.addEventListener("error", () => {
      logo.style.display = "none";
      operatorName.style.display = "inline";
    });

    operatorContainer.append(logo, operatorName);
  } else {
    const operatorName = document.createElement("span");
    operatorName.className = "operator-name";
    operatorName.textContent = operator.name;
    operatorContainer.appendChild(operatorName);
  }

  item.append(
    top,
    details,
    reference,
    commission,
    operatorContainer
  );

  return item;
}

// ==========================================
// SYNCHRONISER LES DATES
// ==========================================

function updateDateDisplays() {
  const dateText = formatDate(selectedDate);

  setText("selectedDate", dateText);
  setText("historySelectedDate", dateText);

  const today = dateKey(new Date());
  const selected = dateKey(selectedDate);

  if ($("nextDay")) {
    $("nextDay").disabled = selected >= today;
  }

  if ($("historyNextDay")) {
    $("historyNextDay").disabled = selected >= today;
  }
}

// ==========================================
// CHARGER L'HISTORIQUE
// ==========================================

async function loadHistory() {
  if (!currentUser) return;

  updateDateDisplays();

  const historyContainer = $("transactionHistory");
  const homeContainer = $("homeTransactionHistory");

  if (historyContainer) historyContainer.replaceChildren();
  if (homeContainer) homeContainer.replaceChildren();

  const start = new Date(selectedDate);
  start.setHours(0, 0, 0, 0);

  const end = new Date(start);
  end.setDate(end.getDate() + 1);

  const { data, error } = await db
    .from("transactions")
    .select(
      "id, transaction_type, amount, client_phone, reference, commission, operator, created_at"
    )
    .eq("user_id", currentUser.id)
    .gte("created_at", start.toISOString())
    .lt("created_at", end.toISOString())
    .order("created_at", { ascending: false });

  if (error) {
    console.error("Erreur historique :", error);

    if (historyContainer) {
      historyContainer.textContent =
        "Impossible de charger l'historique.";
    }

    if (homeContainer) {
      homeContainer.textContent =
        "Impossible de charger les transactions.";
    }

    setText("dailyCommission", "—");
    setText("historyCommission", "—");

    showMessage(
      "historyMessage",
      "Vérifie la connexion et les règles de sécurité.",
      "error"
    );

    showMessage(
      "historyPageMessage",
      "Impossible de charger l'historique.",
      "error"
    );

    return;
  }

  let totalCommission = 0;

  if (!data || data.length === 0) {
    const empty = document.createElement("div");
    empty.className = "empty-state";
    empty.textContent =
      "Aucune transaction pour cette journée.";

    if (historyContainer) {
      historyContainer.appendChild(empty);
    }

    const homeEmpty = document.createElement("div");
    homeEmpty.className = "empty-state";
    homeEmpty.textContent =
      "Aucune transaction pour cette journée.";

    if (homeContainer) {
      homeContainer.appendChild(homeEmpty);
    }

  } else {
    data.forEach((transaction) => {
      totalCommission += Number(transaction.commission || 0);
    });

    if (historyContainer) {
      const fragment = document.createDocumentFragment();

      data.forEach((transaction) => {
        fragment.appendChild(
          createTransactionElement(transaction)
        );
      });

      historyContainer.appendChild(fragment);
    }

    if (homeContainer) {
      const homeFragment = document.createDocumentFragment();

      data.slice(0, 3).forEach((transaction) => {
        homeFragment.appendChild(
          createTransactionElement(transaction)
        );
      });

      homeContainer.appendChild(homeFragment);
    }
  }

  const commissionText = formatMoney(totalCommission);

  setText("dailyCommission", commissionText);
  setText("historyCommission", commissionText);

  showMessage("historyMessage", "");
  showMessage("historyPageMessage", "");
}

// ==========================================
// NAVIGATION ENTRE LES JOURS
// ==========================================

async function changeSelectedDate(direction) {
  const newDate = new Date(selectedDate);
  newDate.setDate(newDate.getDate() + direction);

  if (dateKey(newDate) > dateKey(new Date())) return;

  selectedDate = newDate;
  await loadHistory();
}

on("previousDay", "click", () => changeSelectedDate(-1));
on("nextDay", "click", () => changeSelectedDate(1));
on("historyPreviousDay", "click", () => changeSelectedDate(-1));
on("historyNextDay", "click", () => changeSelectedDate(1));

// ==========================================
// RECHARGEMENT DES TICKETS
// ==========================================

function goToRecharge() {
  window.location.href = "ticket.html";
}

on("rechargeButton", "click", goToRecharge);
on("profileRechargeButton", "click", goToRecharge);

// ==========================================
// MODIFIER LE PROFIL
// ==========================================

on("profileForm", "submit", async (event) => {
  event.preventDefault();

  const firstName = $("profileFirstName").value.trim();
  const lastName = $("profileLastName").value.trim();
  const phone = $("profilePhone").value.trim();

  if (!firstName || !lastName || !phone) {
    showMessage(
      "profileMessage",
      "Tous les champs sont obligatoires.",
      "error"
    );
    return;
  }

  const button = $("saveProfileButton");
  button.disabled = true;
  button.textContent = "Enregistrement...";

  try {
    const { error } = await db
      .from("profiles")
      .update({
        first_name: firstName,
        last_name: lastName,
        phone: phone
      })
      .eq("id", currentUser.id);

    if (error) throw error;

    await loadProfile();

    showMessage(
      "profileMessage",
      "Tes informations ont été mises à jour !",
      "success"
    );

  } catch (error) {
    console.error("Erreur modification profil :", error);

    showMessage(
      "profileMessage",
      error.message || "Impossible de modifier le profil.",
      "error"
    );

  } finally {
    button.disabled = false;
    button.textContent = "Enregistrer les modifications";
  }
});

// ==========================================
// MODIFIER LE MOT DE PASSE
// ==========================================

on("passwordForm", "submit", async (event) => {
  event.preventDefault();

  const password = $("newPassword").value;
  const confirmation = $("confirmNewPassword").value;

  if (password.length < 6) {
    showMessage(
      "passwordMessage",
      "Le mot de passe doit contenir au moins 6 caractères.",
      "error"
    );
    return;
  }

  if (password !== confirmation) {
    showMessage(
      "passwordMessage",
      "Les deux mots de passe ne correspondent pas.",
      "error"
    );
    return;
  }

  const button = $("changePasswordButton");
  button.disabled = true;
  button.textContent = "Modification...";

  try {
    const { error } = await db.auth.updateUser({
      password: password
    });

    if (error) throw error;

    $("passwordForm").reset();

    showMessage(
      "passwordMessage",
      "Mot de passe modifié avec succès !",
      "success"
    );

  } catch (error) {
    console.error("Erreur mot de passe :", error);

    showMessage(
      "passwordMessage",
      error.message || "Impossible de modifier le mot de passe.",
      "error"
    );

  } finally {
    button.disabled = false;
    button.textContent = "Changer le mot de passe";
  }
});

// ==========================================
// AIDE ET À PROPOS
// ==========================================

on("supportButton", "click", () => {
  window.location.href = "support.html";
});

on("aboutButton", "click", () => {
  window.location.href = "apropos.html";
});

// ==========================================
// DÉCONNEXION
// ==========================================

on("logoutButton", "click", async () => {
  const button = $("logoutButton");

  button.disabled = true;
  button.textContent = "Déconnexion...";

  try {
    const { error } = await db.auth.signOut();
    if (error) throw error;

    window.location.replace("auth.html");

  } catch (error) {
    console.error("Erreur déconnexion :", error);

    alert("Impossible de se déconnecter. Réessaie.");

    button.disabled = false;
    button.textContent = "Se déconnecter";
  }
});

// ==========================================
// FENÊTRE DÉPÔT / RETRAIT
// ==========================================

const transactionModal = $("transactionModal");
const transactionForm = $("transactionForm");

const transactionTitle = $("transactionTitle");
const transactionBadge = $("transactionBadge");

const closeTransactionModalButton =
  $("closeTransactionModal");

const saveTransactionButton =
  $("saveTransactionButton");

function openTransactionModal(type) {
  if (
    !transactionModal ||
    !transactionForm ||
    !transactionTitle ||
    !transactionBadge
  ) {
    console.error("Fenêtre transaction introuvable.");
    return;
  }

  selectedTransactionType = type;

  if (type === "deposit") {
    transactionTitle.textContent = "Enregistrer un dépôt";
    transactionBadge.textContent = "DÉPÔT";
  } else {
    transactionTitle.textContent = "Enregistrer un retrait";
    transactionBadge.textContent = "RETRAIT";
  }

  transactionForm.reset();

  $("transactionCommission").value = "0";

  showTransactionMessage("");

  if (saveTransactionButton) {
    saveTransactionButton.disabled = false;
    saveTransactionButton.textContent =
      "Enregistrer la transaction";
  }

  transactionModal.classList.remove("hidden");
  $("transactionAmount").focus();
}

function closeTransactionModal() {
  if (!transactionModal) return;

  transactionModal.classList.add("hidden");

  if (transactionForm) transactionForm.reset();

  showTransactionMessage("");
  selectedTransactionType = null;
}

on("depositButton", "click", () => {
  openTransactionModal("deposit");
});

on("withdrawButton", "click", () => {
  openTransactionModal("withdrawal");
});

if (closeTransactionModalButton) {
  closeTransactionModalButton.addEventListener(
    "click",
    closeTransactionModal
  );
}

if (transactionModal) {
  transactionModal.addEventListener("click", (event) => {
    if (event.target === transactionModal) {
      closeTransactionModal();
    }
  });
}

document.addEventListener("keydown", (event) => {
  if (
    event.key === "Escape" &&
    transactionModal &&
    !transactionModal.classList.contains("hidden")
  ) {
    closeTransactionModal();
  }
});

// ==========================================
// ENREGISTRER UNE TRANSACTION
// ==========================================

if (transactionForm) {
  transactionForm.addEventListener("submit", async (event) => {
    event.preventDefault();

    if (!currentUser || !selectedTransactionType) {
      showTransactionMessage(
        "Session expirée. Reconnecte-toi.",
        "error"
      );
      return;
    }

    const amount = Number($("transactionAmount").value);
    const clientPhone = $("transactionPhone").value.trim();
    const operator = $("transactionOperator").value;
    const reference = $("transactionReference").value.trim();
    const commission = Number($("transactionCommission").value);

    if (!Number.isSafeInteger(amount) || amount <= 0) {
      showTransactionMessage(
        "Saisis un montant entier supérieur à zéro.",
        "error"
      );
      return;
    }

    if (!clientPhone) {
      showTransactionMessage(
        "Le numéro du client est obligatoire.",
        "error"
      );
      return;
    }

    if (!OPERATORS[operator]) {
      showTransactionMessage(
        "Choisis un opérateur Mobile Money.",
        "error"
      );
      return;
    }

    if (!Number.isSafeInteger(commission) || commission < 0) {
      showTransactionMessage(
        "Saisis une commission entière positive ou égale à zéro.",
        "error"
      );
      return;
    }

    if (saveTransactionButton) {
      saveTransactionButton.disabled = true;
      saveTransactionButton.textContent = "Enregistrement...";
    }

    showTransactionMessage(
      "Enregistrement de la transaction en cours..."
    );

    try {
      const { data, error } = await db.rpc(
        "enregistrer_transaction",
        {
          p_transaction_type: selectedTransactionType,
          p_amount: amount,
          p_client_phone: clientPhone,
          p_reference: reference || null,
          p_commission: commission,
          p_operator: operator
        }
      );

      if (error) throw error;

      if (!data || data.success !== true) {
        throw new Error(
          "La transaction n'a pas été confirmée par le serveur."
        );
      }

      showTransactionMessage(
        "Transaction enregistrée avec succès ! Un ticket a été consommé.",
        "success"
      );

      if (saveTransactionButton) {
        saveTransactionButton.textContent = "Enregistré";
      }

      try {
        await loadProfile();
        await loadHistory();
      } catch (refreshError) {
        console.error(
          "Actualisation après transaction impossible :",
          refreshError
        );
      }

      setTimeout(() => {
        closeTransactionModal();
      }, 1200);

    } catch (error) {
      console.error("Erreur transaction :", error);

      const errorText = error.message || "";

      if (errorText.toLowerCase().includes("ticket")) {
        showTransactionMessage(
          "Solde de tickets insuffisant. Recharge tes tickets.",
          "error"
        );
      } else {
        showTransactionMessage(
          errorText || "Impossible d'enregistrer la transaction.",
          "error"
        );
      }

      if (saveTransactionButton) {
        saveTransactionButton.disabled = false;
        saveTransactionButton.textContent =
          "Réessayer l'enregistrement";
      }
    }
  });
}

// ==========================================
// INITIALISATION
// ==========================================

async function initDashboard() {
  try {
    const { data, error } = await db.auth.getSession();

    if (error) throw error;

    if (!data.session) {
      window.location.replace("auth.html");
      return;
    }

    currentUser = data.session.user;

    await loadProfile();

    selectedDate = new Date();
    await loadHistory();

    showPage("homePage");

  } catch (error) {
    console.error("Initialisation impossible :", error);

    setText("agentName", "Erreur de chargement");
    setText("userId", "Indisponible");
    setText("ticketBalance", "—");

    showMessage(
      "historyMessage",
      error.message || "Impossible de charger Mobiflow.",
      "error"
    );

    showMessage(
      "historyPageMessage",
      error.message || "Impossible de charger Mobiflow.",
      "error"
    );
  }
}

initDashboard();

// ==========================================
// PROTECTION DE L'INTERFACE
// ==========================================

// Note : ces protections ne remplacent pas la sécurité
// de la base de données et des règles RLS Supabase.

document.addEventListener("contextmenu", (event) => {
  event.preventDefault();
});

document.addEventListener("selectstart", (event) => {
  if (!event.target.closest("input, textarea")) {
    event.preventDefault();
  }
});

document.addEventListener("copy", (event) => {
  event.preventDefault();
});

document.addEventListener("cut", (event) => {
  event.preventDefault();
});

document.addEventListener("keydown", (event) => {
  const key = event.key.toLowerCase();

  if (
    (event.ctrlKey || event.metaKey) &&
    ["c", "x", "u", "s", "a"].includes(key)
  ) {
    event.preventDefault();
  }
});
