
/* =========================================
   VENUN SDK — VERSION 2.0
   Moteur intelligent de diffusion
   Gestion des campagnes et versions APK
========================================= */

(function () {
    "use strict";

    const SDK = {

        client: null,
        appId: null,
        appVersion: "0.0.0",
        userRef: null,
        currentCampaign: null,

        /* =====================================
           INITIALISATION
        ===================================== */

        async init(config) {

            if (!window.supabase?.createClient) {
                console.error("VENUN SDK : Supabase JS absent.");
                return;
            }

            this.appId = config.appId;
            this.appVersion = config.appVersion || "0.0.0";
            this.userRef = config.userRef || null;

            this.client = window.supabase.createClient(
                config.supabaseUrl,
                config.supabaseKey
            );

            console.log(
                "VENUN SDK connecté :",
                this.appId,
                "Version :",
                this.appVersion
            );

            await this.loadCampaigns();
        },

        /* =====================================
           COMPARAISON DES VERSIONS
        ===================================== */

        compareVersions(current, target) {

            const parse = (version) => {
                return String(version)
                    .trim()
                    .replace(/^v/i, "")
                    .split(".")
                    .map(part => {
                        const number = parseInt(part, 10);
                        return Number.isFinite(number) ? number : 0;
                    });
            };

            const a = parse(current);
            const b = parse(target);

            const length = Math.max(a.length, b.length);

            for (let i = 0; i < length; i++) {

                const currentPart = a[i] || 0;
                const targetPart = b[i] || 0;

                if (currentPart < targetPart) return -1;
                if (currentPart > targetPart) return 1;
            }

            return 0;
        },

        /* =====================================
           RÉCUPÉRATION DES CAMPAGNES
        ===================================== */

        async loadCampaigns() {

            try {

                const { data, error } = await this.client
                    .from("sdk_campaigns")
                    .select("*")
                    .in("app_id", ["*", this.appId])
                    .eq("status", "active")
                    .order("priority", { ascending: false });

                if (error) throw error;

                if (!data || data.length === 0) {
                    console.log("VENUN SDK : Aucune campagne.");
                    return;
                }

                // Filtrer les campagnes selon leur version
                const campaigns = data.filter(campaign => {

                    // Vérification spéciale des mises à jour
                    if (campaign.type === "update") {

                        const targetVersion =
                            campaign.payload?.version;

                        if (!targetVersion) {
                            return false;
                        }

                        // Notification uniquement aux anciennes versions
                        return this.compareVersions(
                            this.appVersion,
                            targetVersion
                        ) < 0;
                    }

                    // Les autres campagnes restent compatibles
                    return true;
                });

                if (campaigns.length === 0) {
                    console.log(
                        "VENUN SDK : Aucune campagne applicable."
                    );
                    return;
                }

                // Afficher la campagne prioritaire
                this.showCampaign(campaigns[0]);

            } catch (error) {

                console.error(
                    "VENUN SDK :",
                    error.message
                );
            }
        },

        /* =====================================
           AFFICHAGE D'UNE CAMPAGNE
        ===================================== */

        showCampaign(campaign) {

            // Éviter les fenêtres en double
            document.getElementById(
                "venun-sdk-overlay"
            )?.remove();

            this.currentCampaign = campaign;

            const overlay = document.createElement("div");
            overlay.className = "venun-overlay";
            overlay.id = "venun-sdk-overlay";

            const modal = document.createElement("div");
            modal.className = "venun-modal";

            const title = document.createElement("h2");
            title.textContent = campaign.title;

            const content = document.createElement("div");
            content.className = "venun-content";

            modal.append(title, content);

            const payload = campaign.payload || {};

            if (campaign.type === "survey") {

                this.renderSurvey(content, campaign, payload);

            } else if (campaign.type === "update") {

                this.renderUpdate(content, campaign, payload);

            } else if (campaign.type === "maintenance") {

                this.renderMaintenance(content, campaign, payload);

            } else {

                this.renderMessage(content, campaign, payload);
            }

            if (campaign.mode !== "required") {

                const close = document.createElement("button");

                close.className = "venun-secondary";
                close.textContent = "Continuer / Ignorer";
                close.onclick = () => this.close();

                modal.appendChild(close);
            }

            overlay.appendChild(modal);
            document.body.appendChild(overlay);
        },

        /* =====================================
           SONDAGES
        ===================================== */

        renderSurvey(container, campaign, payload) {

            const description = document.createElement("p");
            description.textContent = payload.description || "";

            container.appendChild(description);

            const question = document.createElement("h3");

            question.textContent =
                payload.question || "Votre avis nous intéresse";

            container.appendChild(question);

            const form = document.createElement("form");

            (payload.options || []).forEach(option => {

                const label = document.createElement("label");
                label.className = "venun-option";

                const radio = document.createElement("input");

                radio.type = "radio";
                radio.name = "venun-answer";
                radio.value = option;
                radio.required = true;

                label.append(
                    radio,
                    document.createTextNode(" " + option)
                );

                form.appendChild(label);
            });

            const submit = document.createElement("button");

            submit.type = "submit";
            submit.className = "venun-primary";
            submit.textContent = "Envoyer ma réponse";

            form.appendChild(submit);

            form.onsubmit = async (event) => {

                event.preventDefault();

                const selected = form.querySelector(
                    'input[name="venun-answer"]:checked'
                );

                if (!selected) return;

                const { error } = await this.client
                    .from("sdk_survey_responses")
                    .insert({
                        campaign_id: campaign.id,
                        app_id: this.appId,
                        user_ref: this.userRef,
                        answer: {
                            response: selected.value
                        }
                    });

                if (error) {

                    alert("Impossible d'envoyer votre réponse.");
                    console.error(error);
                    return;
                }

                alert("Merci pour votre participation !");

                this.close();
            };

            container.appendChild(form);
        },

        /* =====================================
           MISES À JOUR APK
        ===================================== */

        renderUpdate(container, campaign, payload) {

            const message = document.createElement("p");

            message.textContent =
                payload.message ||
                "Une nouvelle version est disponible.";

            container.appendChild(message);

            if (payload.version) {

                const version = document.createElement("p");

                version.textContent =
                    "Version : " + payload.version;

                container.appendChild(version);
            }

            // Accepter les deux formats de lien
            const downloadUrl =
                payload.download_url || payload.link;

            if (downloadUrl) {

                const link = document.createElement("a");

                link.className = "venun-primary";
                link.href = downloadUrl;
                link.target = "_blank";
                link.rel = "noopener noreferrer";

                link.textContent =
                    payload.button_text ||
                    "Télécharger la mise à jour";

                container.appendChild(link);
            }
        },

        /* =====================================
           MAINTENANCE
        ===================================== */

        renderMaintenance(container, campaign, payload) {

            const message = document.createElement("p");

            message.textContent =
                payload.message ||
                "Application temporairement indisponible.";

            container.appendChild(message);
        },

        /* =====================================
           MESSAGES
        ===================================== */

        renderMessage(container, campaign, payload) {

            const message = document.createElement("p");

            message.textContent =
                payload.message || payload.description || "";

            container.appendChild(message);

            if (payload.button_url) {

                const link = document.createElement("a");

                link.className = "venun-primary";
                link.href = payload.button_url;
                link.target = "_blank";
                link.rel = "noopener noreferrer";

                link.textContent =
                    payload.button_text || "En savoir plus";

                container.appendChild(link);
            }
        },

        /* =====================================
           FERMETURE
        ===================================== */

        close() {

            document.getElementById(
                "venun-sdk-overlay"
            )?.remove();

            this.currentCampaign = null;
        }
    };

    window.VENUNSDK = SDK;

})();
